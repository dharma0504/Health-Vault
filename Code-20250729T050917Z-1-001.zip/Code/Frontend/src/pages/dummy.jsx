import React from 'react'

const dummy = () => {
  return (
    <div Link to="/">
    </div>
  )
}

export default dummy
